SNMP Trap Watcher
Version: 1.41
Author and Copyright: 1998-2013, BTT Software, All Rights Reserved

This version of SNMP Trap Watcher is provided as FREEWARE, and consequently,
there is only limited email support provided.

email:   nabbott@bttsoftware.co.uk
website: http://www.bttsoftware.co.uk/

